
        function cargarFondo() {
            let valor = document.getElementById("imagenCargada").files[0].name;
            console.log(valor);
            document.getElementById("divImagen").style.backgroundImage = `url('${valor}')`
        }
