<?php
$server = "localhost";
$user = "root";
$contraseña = "123";
$bd = "hotlinexdb";
$conexion = mysqli_connect($server,$user,$contraseña,$bd) or die ("error siu");

?>