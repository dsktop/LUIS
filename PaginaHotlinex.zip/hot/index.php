<?php
$server = "localhost";
$user = "root";
$contraseña = "123";
$bd = "hotlinexdb";
$conexion = mysqli_connect($server,$user,$contraseña,$bd) or die ("error siu");
$ruta = "";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css"/>
    <title>Tailwind</title>
    <link rel="icon" type="image/png" href="img/iconowendys.jpg">
    
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/62cb099bac.js" crossorigin="anonymous"></script>
</head>
<body id="body-bg">
    <div id="nav-barsm" class="w-full bg-black "><p>Bienvenido</p></div>
    <div id="cd" class="md:flex md:w-full h-30">
        <a href="index.php"><img src="assets/logo/logohot.png" class="w-80 mb-2 ml-5" alt="Hotlinex Logo"></a>
        <input type="text" placeholder="Buscar modelos..." class="w-2/5  hidden md:block rounded-full h-10 mt-10 ml-14 mr-8 rounded pl-3">
        <a href="ingreso.php"><button class="w-36 h-10  hidden md:block rounded-full mt-10 ml-10 mr-16 text-white border-white border-2 border-solid hover:bg-white hover:text-black transition font-bold"><i class="fas fa-circle mr-4 "></i>Ingresar</button></a>
        <a href="registro.php"><button class="w-40 h-10  hidden md:block rounded-full mt-10 mr-14 text-white border-white border-2 border-solid hover:bg-white hover:text-black font-bold"><i class="fas fa-circle mr-4"></i>Registrate</button></a>
    </div>
    <div class="flex h-screen">
    <div id="sidebar" class="bg-black md:w-48 hidden md:block h-screen ">
        
        <p class="text-white text-lg ml-7 mb-2">Chicas | Chicos</p>
    
        <label id="circle-chicos-chicas" class="circulo-up"></label>

        <ul class="mt-14">
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="fas fa-home"></i> Inicio</a></li>
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="fas fa-star"></i> Destacados</a></li>
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="fas fa-newspaper"></i> Nuevos</a></li>
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="far fa-gem"></i> VIP</a></li>
        </ul>
    </div>

    <div class="p-6 w-full block">
        <h6 class=" text-xl text-white font-bold mb-10"><i id="circulo-1" class="fas fa-circle text-black text-xl mr-3"></i>Chats Destacados del Mes</h6>
        
        <div class="grid grid-cols-1 h-24 sm:grid-cols-4 mb-6 gap-6">

            <div id="chat-destacado-1" class=" rounded-lg shadow-sm inline-flex">
                <div id="img-profile" class="rounded-full bg-white ml-2.5 mt-2.5" ></div>

                <div class="block">
                    <div id="header-chat-destacado" class="inline-flex w-full">

                        <div id="vip" class="text-left text-xs  w-9 rounded-full h-4 text-center absolute font-bold mt-0.5 ml-14 text-black"><p>VIP</p></div>

                        <div id="Estado-" class=" text-right ml-24 text-sm   text-white font-bold"><p><i style="color: #5BFB66;" class="fas fa-circle mr-1 "></i>En linea</p></div>
                        
                    </div>

                    <div id="nombre-perfil-destacado" class="font-bold w-44  ml-1.5 mt-0 text-white"> <p>Merenge con pollo13</p> </div>

                    <div id="edad-perfil-destacado" class="font-bold w-44  ml-1.5 mt-1 text-white"> <p>20 años</p> </div>
                </div>
            </div>
            

            <div id="chat-destacado-2" class="  rounded-lg shadow-sm">
                <div id="img-profile" class="rounded-full bg-white ml-2.5 mt-2.5" >
                </div>
            </div>

            <div id="chat-destacado-3" class="  rounded-lg shadow-sm">
                <div id="img-profile" class="rounded-full bg-white ml-2.5 mt-2.5" >
                </div>
            </div>

            <div id="chat-destacado-4" class=" rounded-lg shadow-sm">
                <div id="img-profile" class="rounded-full bg-white ml-2.5 mt-2.5" >
                </div>
            </div>

        </div>

        
        <div class="grid grid-cols-1 sm:grid-cols-1 mt-10 mb-6 gap-6">
            <h6 class=" text-xl text-white font-bold "><i id="circulo-1" class="fas fa-circle text-black text-xl mr-3"></i>Chats Calientes Gratis 🔥</h6>
        </div>
        
    
    
        
    <div id="chats-container2" class="grid grid-cols-4 2xl:grid-cols-2 h-24 mb-10 mt-5 gap-6 mr-2">

      <?php
      $sql="SELECT * from datos_de_usuario";
      $result=mysqli_query($conexion,$sql);

      
      while($mostrar=mysqli_fetch_array($result)){
       ?>   
      
    
    <a href="chat.php?variable=<?php echo $mostrar['usuario'];?>" name="estado">  <div id="chat-num-">
        
            <div id="estado-chat-" class="inline-flex">
                <p class="text-white font-bold"><i id="circulo-1" class="fas fa-circle text-white font-bold mr-1"></i><?php echo $mostrar['estado']?></p> 
                <div id="vip" class="text-left text-xs hidden  w-9 rounded-full h-4 text-center absolute font-bold ml-60 mt-0.5  text-black"><p>VIP</p></div>
            </div>
            <div id="container-chat" class="bg-white ">
                <div id="img-perfil-chat" class=" w-full h-full">
                    <div id="bg-nombre-perfil-chat" class="w-full h-10 top-44 text-white inline-flex">                                
                        <div id="nombre-perfil-chat" class="ml-2 font-bold">
                            <p id="poto" value="<?php echo $mostrar['usuario']?>" ><?php echo $mostrar['usuario']?></p>
                        </div>
                        <div id="edad1" class="w-1/4 h-3 absolute ml-60 text-center font-bold text-sm mt-0.5">
                            <p><?php echo $mostrar['edad']?></p>
                            <img class="mx-auto" src="img\cl.png" width="23px" alt="img no encontrada">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </a>
    
    
    
    <?php
    }
    ?>



    
    </div>

</div>
<script>
    var boygirl = document.getElementById('circle-chicos-chicas');
    boygirl.addEventListener('click',function(){
        boygirl.classList.toggle('active');
        setTimeout(function(){
            document.location.href="index-boys.html";
            
        },500);
    })
 </script>

<!-- <script>
    var nombres =["Monserrat-Soft","Mariella24","LorenaMoon","ola","carlos2","poot3","si4","ola5"];
    var x = [0];
    var estructura = "";
    var id = "";
    var name = "olasi";
    
   

    for (let a = 0; a < x.length; a++){
        id += `poto`
    }
    
        estructura += `<p id="${id}">${nombres[0]}</p>`
    

     document.getElementById("poto").innerHTML = estructura;
</script> -->

<script>
    var vip = document.getElementById('vip');
    if (vip) {
        document.getElementById('vip').style.visibility = "visible";
    }
    
</script>

</body>
</html>