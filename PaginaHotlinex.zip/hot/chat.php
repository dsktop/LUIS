<?php
$server = "localhost";
$user = "root";
$contraseña = "123";
$bd = "hotlinexdb";
$conexion = mysqli_connect($server,$user,$contraseña,$bd) or die ("error siu");



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <Link rel="stylesheet" href="css/style.css"/>
    <title>Tailwind</title>
    <script src="nombredechat.js" language="javascript" type="text/javascript"></script>
    <link href="https://fonts.googleapis.com/css2?family=Mulish&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="img/iconowendys.jpg">
    <script src="https://kit.fontawesome.com/62cb099bac.js" crossorigin="anonymous"></script>
    <!--<script type="text/javascript" >
        function Darkmode(){
            document.getElementById("chat-bg").style.backgroundColor="#1A1919";
                
            
        }
    </script>-->
    


</head>
<body id="body-bg">
<div class="padre relative  ">


    <div id="nav-barsm" class="w-full bg-black "><p>Bienvenido</p></div>
    <div id="cd" class="md:flex md:w-full h-30">
    <a href="index.php"><img src="assets/logo/logohot.png" class="w-80 mb-2 ml-5" alt="Hotlinex Logo"></a>
        <input type="text" placeholder="Buscar modelos..." class="w-2/5  hidden md:block rounded-full h-10 mt-10 ml-14 mr-8 rounded pl-3">
        <a href="ingreso.php"><button class="w-36 h-10  hidden md:block rounded-full mt-10 ml-10 mr-16 text-white border-white border-2 border-solid hover:bg-white hover:text-black transition font-bold"><i class="fas fa-circle mr-4 "></i>Ingresar</button></a>
        <a href="registro.php"><button class="w-40 h-10  hidden md:block rounded-full mt-10 mr-14 text-white border-white border-2 border-solid hover:bg-white hover:text-black font-bold"><i class="fas fa-circle mr-4"></i>Registrate</button></a>
    </div>
    <div class="flex h-screen">
    <div id="sidebar" class="bg-black md:w-48 hidden md:block h-screen ">
        <p class="text-white text-lg ml-7 mb-2">Chicas | Chicos</p>
    
        <label id="circle-chicos-chicas" class="circulo-up"></label>
        
        <ul class="mt-14">
            <li class="mb-3 ml-7"><a href="index.html" class="text-white text-lg"><i class="fas fa-home"></i> Inicio</a></li>
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="fas fa-star"></i> Destacados</a></li>
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="fas fa-newspaper"></i> Nuevos</a></li>
            <li class="mb-3 ml-7"><a href="" class="text-white text-lg"><i class="far fa-gem"></i> VIP</a></li>
        </ul>
    </div>
    <?php
      $sql="SELECT * from datos_de_usuario";
      $result=mysqli_query($conexion,$sql);
      $mostrar=mysqli_fetch_array($result)
      
       ?>   

<div class="p-6 w-full block">
            
    <div class="inline-flex w-full " >
            

            <div id="chat-bg" class="chat-bg mt-10 md:block ">
                <div id="header-chat" class="inline-flex p-1 pl-3 bg-white w-full">
                    <div id="foto-perfil" class="bg-black h-16 w-16 rounded-full">

                    </div>

                    <div id="container-datos" class="mt-5">
                        
                        <div id="nombre-de-usuario" class="text-white w-2/3 text-xl md:  text-xl  ml-3 mt-2 w-1/3">
                            <p> <?php echo $_GET['variable']; ?></p>
                            
                            <div class="inline-flex">
                                <div id="estado-icon" class=" rounded-full w-4 h-4 mt-1">
                                
                                </div>
                                <div id="estado" class="font-bold ml-1 mt-0.5 w-16 text-sm">
                                    <p><?php echo $mostrar['estado']?></p>
                                </div>
    
                                <div id="darkmode-lightmode" class="-mt-6 ml-96 inline-flex ">
                                    <i class="fas fa-moon fa-2x"></i> 
                                    
                                        <label id="dark-change"class="label" ></label>
                                    <!--<button  onclick="Darkmode()"  class="w-24 h-8  hidden md:block rounded-full mt-1 ml-2 text-black border-black border-2 border-solid hover:bg-white "><i class="fas fa-circle mr-16"></i></button>-->
                                </div>
    
    
    
                            </div>
                            
                        </div>
                    </div>
                   
                
                   
                   

                </div>
                <div id="notificacion" class="inline-flex mt-1 ">
                    <p id="text-alert" class="ml-12 mt-2">Mejora tu noche comprando fotos y videos exclusivos</p>
                    <button id="boton-alert" class="rounded-full ml-20 font-bold">Comprar!</button>
                    <button  id="cerrar-notificacion" class="mt-2"> <p id="cerrar">x</p> </button>
                </div>
                

                <div id="footer-chat ">
                    <div id="text-input" class="bg-gray-300 w-11/12 h-12 rounded-full mx-auto ">
                        <input type="text" placeholder="Ingresa Mensaje" name="chat-input" id="mensaje" class="mensaje mx-auto h-10 w-10/12 ml-5 " >


                    </div>

                </div>

            </div>


    

        <div class="block mx-auto">
            <div id="chats-recientes" class=" inline-flex h-10 w-60 -ml-7">
                <h6 class=" text-xl text-white font-bold "><i id="circulo-1" class="fas fa-circle text-black text-xl mr-3"></i>Chats Recomendados </h6>
            </div>
            <div id="chats-container" class="grid grid-cols-1 2xl:grid-cols-2 h-24 mb-10 mt-5 gap-6">

            <?php
      $sql="SELECT * from datos_de_usuario";
      $result=mysqli_query($conexion,$sql);

      
      while($mostrar=mysqli_fetch_array($result)){
       ?>   
      
    
    <!-- <a href="chat.php?variable=<?php echo $mostrar['usuario'];?>" id="" name="estado">  <div id="chat-num-">
        
            <div id="estado-chat-" class="inline-flex">
                <p class="text-white font-bold"><i id="circulo-1" class="fas fa-circle text-white font-bold mr-1"></i><?php echo $mostrar['estado']?></p> 
                <div id="vip" class="text-left text-xs hidden  w-9 rounded-full h-4 text-center absolute font-bold ml-60 mt-0.5  text-black"><p>VIP</p></div>
            </div>
            <div id="container-chat" class="bg-white ">
                <div id="img-perfil-chat" class=" w-full h-full">
                    <div id="bg-nombre-perfil-chat" class="w-full h-10 top-44 text-white inline-flex">                                
                        <div id="nombre-perfil-chat" class="ml-2 font-bold">
                            <p id="poto"  value="<?php echo $mostrar['usuario']?>"><?php echo $mostrar['usuario']?></p>
                        </div>
                        <div id="edad1" class="edad w-1/4 h-3 absolute ml-56 text-center font-bold text-sm mt-0.5">
                            <p><?php echo $mostrar['edad']?></p>
                            <img class="mx-auto" src="img\cl.png" width="23px" alt="img no encontrada">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </a> -->
    
    
    
    <?php
    }
    ?>
            </div>-->
        </div> 
    </div>

        <div id="banner-publicidad" class=" bg-white hidden md:block mt-10">
            <iframes src="//a.realsrv.com/iframe.php?idzone=4462452&size=728x90" width="728" height="90" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>
        </div>

        <div id="chats-sugeridos" class="mt-8  w-2/4">
            <h6 class=" text-xl text-white font-bold "><i id="circulo-1" class="fas fa-circle text-black text-xl mr-3"></i>Chats Calientes 🥵 </h6>
        </div><br>

        <div id="chats-container2" class="grid grid-cols-4 2xl:grid-cols-2 h-24 mb-10 mt-5 gap-6 mr-2">

        <?php
      $sql="SELECT * from datos_de_usuario";
      $result=mysqli_query($conexion,$sql);

      
      while($mostrar=mysqli_fetch_array($result)){
       ?>   
      
    
    <a href="chat.php?variable=<?php echo $mostrar['usuario'];?>" id="" name="estado">  <div id="chat-num-">
        
            <div id="estado-chat-" class="inline-flex">
                <p class="text-white font-bold"><i id="circulo-1" class="fas fa-circle text-white font-bold mr-1"></i><?php echo $mostrar['estado']?></p> 
                <div id="vip" class="text-left text-xs hidden  w-9 rounded-full h-4 text-center absolute font-bold ml-60 mt-0.5  text-black"><p>VIP</p></div>
            </div>
            <div id="container-chat" class="bg-white ">
                <div id="img-perfil-chat" class=" w-full h-full">
                    <div id="bg-nombre-perfil-chat" class="w-full h-10 top-44 text-white inline-flex">                                
                        <div id="nombre-perfil-chat" class="ml-2 font-bold">
                            <p id="poto"  value="<?php echo $mostrar['usuario']?>"><?php echo $mostrar['usuario']?></p>
                        </div>
                        <div id="edad1" class="edad w-1/4 h-3 absolute ml-56 text-center font-bold text-sm mt-0.5">
                            <p><?php echo $mostrar['edad']?></p>
                            <img class="mx-auto" src="img\cl.png" width="23px" alt="img no encontrada">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </a>
    
    
    
    <?php
    }
    ?>


    </div>

    
    


</div>
</div><!--padre-->
</body>

</html>

<script>
    document.getElementsByClassName('left')
</script>

<script>
                        
                            
    var content = document.getElementsByClassName('chat-bg')[0];
    var darkMode = document.getElementById('dark-change');
    darkMode.addEventListener('click', function(){
        darkMode.classList.toggle('active');
        content.classList.toggle('night');
    }) 
 
 </script>
 <script>
    var boygirl = document.getElementById('circle-chicos-chicas');
    boygirl.addEventListener('click',function(){
        boygirl.classList.toggle('active');
        setTimeout(function(){
            document.location.href="index3.html";
            
        },300);
    })
 </script>

 <script>
    var closeNotificacion = document.getElementById('cerrar-notificacion');
    var notificacion = document.getElementById('notificacion');
    closeNotificacion.addEventListener('click',function(){
        notificacion.style.visibility = 'hidden';
    })


 </script>
   
