// Bootstrap's JS'
const bootstrap = require('bootstrap');

// Make bootstrap's js available via the window object
// (Used in the tooltip example)
window.bootstrap = bootstrap;
